/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cmu.andrew.msatam;


import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author mansi
 */
@WebService(serviceName = "BlockChainWebService")
public class BlockChainWebService {

    /**
     * Web service operation
     * adds the transaction entered by the user to the blockchain
     * 
     */
    BlockChain b;
    int blockCount = 0;
    BigInteger e = new BigInteger("65537");
    BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");

    
    @WebMethod(operationName = "addTransaction")
    public long addTransaction(@WebParam(name = "difficulty") int difficulty, @WebParam(name = "transaction") String transaction) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        
        Timestamp timestamp1 = b.getTime();
        String[] strarray = transaction.split("#");
        // Take the encrypted string and make it a big integer
        BigInteger encryptedHash = new BigInteger(strarray[1]);
        // Decrypt it
        BigInteger decryptedHash = encryptedHash.modPow(e, n);
        
        // Get the bytes from messageToCheck
        byte[] bytesOfMessageToCheck = strarray[0].getBytes("UTF-8");
       
        // compute the digest of the message with SHA-256
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] messageToCheckDigest = md.digest(bytesOfMessageToCheck);
        int length = messageToCheckDigest.length;
        byte[] extrabyte = new byte[length+1];
        int i;
        extrabyte[0]=0; 
        for(i=1;i<length;i++){
                        
           extrabyte[i] = messageToCheckDigest[i];
                        
        }
        BigInteger bigIntegerToCheck = new BigInteger(extrabyte);
        // If this new hash is equal to the decrypted hash then the signature has been verified. 
        //If it is not equal, the data may have been tampered with.
        if(bigIntegerToCheck.compareTo(decryptedHash) == 0) {
            
        Block block = new Block(blockCount, timestamp1, transaction, difficulty);
        block.setPreviousHash(b.chainHash);
        b.addBlock(block);
        Timestamp timestamp2 = b.getTime();
        long executionTime;
        executionTime = timestamp2.getTime() - timestamp1.getTime();
        blockCount=blockCount+1;
        return executionTime;
            
        }
        return 0;
        
        
    }

    /**
     * Web service operation
     * validates the entire blockchain.
     * If the chain only contains one block, the genesis block at position 0, 
     * this routine computes the hash of the block and checks that the hash has the requisite number of leftmost 0's (proof of work) 
     * as specified in the difficulty field.
     * 
     */
    @WebMethod(operationName = "validateChain")
    public boolean validateChain() throws NoSuchAlgorithmException, UnsupportedEncodingException {
        
        boolean result;
        result = b.isChainValid();  
        return result;
    }

    /**
     * Web service operation
     * displays the entire blockchain
     */
    @WebMethod(operationName = "display")
    public String display() throws NoSuchAlgorithmException, UnsupportedEncodingException {
        
        String string;
        string = b.toString(); 
        return string;
    }

    /**
     * Web service operation
     * initializes the blockchain
     */
    @WebMethod(operationName = "init")
    public void init() throws NoSuchAlgorithmException, UnsupportedEncodingException {
        
        b = new BlockChain();
        blockCount = blockCount+1;
    }
}
