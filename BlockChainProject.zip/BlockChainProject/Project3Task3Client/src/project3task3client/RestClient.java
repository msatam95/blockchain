/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3task3client;

/**
 *
 * @author mansi
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

// A simple class to wrap a result.
class Result {

    String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}

public class RestClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        // TODO code application logic here

        int choice;
        int difficulty;
        String transaction;
        BigInteger e = new BigInteger("65537");
        BigInteger d = new BigInteger("339177647280468990599683753475404338964037287357290649639740920420195763493261892674937712727426153831055473238029100340967145378283022484846784794546119352371446685199413453480215164979267671668216248690393620864946715883011485526549108913");
        BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
        //init();

        do {
            System.out.println("Block Chain Menu");
            System.out.println("1.Add a transaction to the blockchain");
            System.out.println("2.Verify the blockchain");
            System.out.println("3.View the blockchain");
            System.out.println("4.Exit");
            System.out.println("Select a choice:");
            Scanner sc = new Scanner(System.in);
            choice = sc.nextInt();

            switch (choice) {

                case 1:

                    System.out.println("Enter difficulty > 0");
                    difficulty = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter transaction:");
                    transaction = sc.nextLine();
                    //encode the transaction here
                    //compute the digest with SHA-256
                    long startTime = System.currentTimeMillis();
                    
                    byte[] bytesOfMessage = transaction.getBytes("UTF-8");
                    MessageDigest md = MessageDigest.getInstance("SHA-256");
                    byte[] bigDigest = md.digest(bytesOfMessage);
                    int length = bigDigest.length;
                    byte[] messageDigest = new byte[length+1];
                    int i;
                    messageDigest[0]=0; 
                    for(i=1;i<length;i++){
                        
                        messageDigest[i] = bigDigest[i];
                        
                    }
                    // From the digest, create a BigInteger
                    BigInteger m = new BigInteger(messageDigest); 
                    // encrypt the digest with the private key
                    BigInteger c = m.modPow(d, n);  
                    transaction = transaction+"#"+c.toString();
                    assign(difficulty,transaction);
                    
                    long endTime = System.currentTimeMillis();
                    long executionTime = endTime - startTime;
                    System.out.println("Total execution time to add this block was " + executionTime + " milliseconds");
                    break;

                case 2:

                    System.out.println("Verifying the entire chain");
                    long startTimeToVerify = System.currentTimeMillis();
                    String result = read("2");
                    long endTimeToVerify = System.currentTimeMillis();
                    
                    if (result.equals("true")) {
                        System.out.println("Chain verification: true");
                    } else {

                        System.out.println("Chain verification: false");

                    }
                    break;

                case 3:

                    System.out.println("View the BlockChain");
                    String chain = read("3");
                    System.out.println(chain);
                    break;

                case 4:

                    break;

            }
        } while (choice != 4);
    }

    
    
// assign a string value to a string name (One character names for demo)

    public static boolean assign(int difficulty, String transaction) {
        // We always want to be able to assign so we may need to PUT or POST.
        // Try to PUT, if that fails then try to POST
        if(doPost(difficulty,transaction) == 200) {
            return true;
        } else {
                return false;
            }
        
    }

    // read a value associated with a name from the server
    // return either the value read or an error message
    public static String read(String option) {
        Result result = new Result();
        int status = 0;
        if ((status = doGet(option,result)) != 200) {
            return "Error from server " + status;
        }
        return result.getValue();
    }

    

    // Low level routine to make an HTTP POST request
    // Note, POST does not use the URL line for its message to the server
    public static int doPost(int difficulty, String transaction) {

        int status = 0;
        String output;

        try {
            URL url = new URL("http://localhost:8080/Project3Task3Server/BlockChainServer");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
            out.write(difficulty+"@"+transaction);
            
            out.close();
            status = conn.getResponseCode();
            conn.disconnect();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // return HTTP status
        return status;
    }

    public static int doGet(String option,Result result) {

        // Make an HTTP GET passing the name on the URL line
        result.setValue("");
        String response = "";
        HttpURLConnection conn;
        int status = 0;

        try {

            // pass the name on the URL line
            URL url = new URL("http://localhost:8080/Project3Task3Server/BlockChainServer"+ "/" + option);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            // tell the server what format we want back
            conn.setRequestProperty("Accept", "text/plain");

            // wait for response
            status = conn.getResponseCode();

            // If things went poorly, don't try to read any response, just return.
            if (status != 200) {
                
                return conn.getResponseCode();
            }
            String output = "";
            // things went well so let's read the response
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));

            while ((output = br.readLine()) != null) {
                response += output;

            }
            
            result.setValue(response);
            conn.disconnect();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // return HTTP status to caller
        return status;
    }

    

    
}
