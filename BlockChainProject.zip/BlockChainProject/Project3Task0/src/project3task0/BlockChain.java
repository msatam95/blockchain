/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3task0;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Scanner;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author mansi
 */
public class BlockChain {

    /**
     * @param args the command line arguments
     */
    static ArrayList<Block> Blocks = null;
    //initializing the Arraylist of blocks 
    static String chainHash = null;
    //initializing the chainhash variable to store the latest hash value
    static int blockCount = 0;

    BlockChain() {

        Blocks = new ArrayList<>();
        chainHash = "";

    }

    /**
     *
     * @param args
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     * Presents a menu to the user to add a transaction, view the blockchain, verify the transaction, corrupt the blockchain and
     * to repair the blockchain.
     * To add a block with difficulty 2 the average time is 25 milliseconds, while for blocks of difficulty 4 the average time
     * is 420 milliseconds and for the block of difficulty 5 the average time  is 2750 milliseconds
     * We can therefore see that as the difficulty increases time required to execute proof of work increases.
     * Verifying takes on an average 0 milliseconds as the nonce is known.
     */
    public static void main(String[] args) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        
        int difficulty;
        String transaction;
        //the blockchain is initialized
        BlockChain b = new BlockChain();
        Block block0 = new Block(0, b.getTime(), "Genesis", 2);
        block0.setPreviousHash(chainHash);
        //add the genesis block to the chain
        b.addBlock(block0);
        int choice;
        do {
            
            System.out.println("Block Chain Menu");
            System.out.println("0. View basic blockchain status");
            System.out.println("1.Add a transaction to the blockchain");
            System.out.println("2.Verify the blockchain");
            System.out.println("3.View the blockchain");
            System.out.println("4.Corrupt the chain");
            System.out.println("5.Hide the corruption by repairing the chain");
            System.out.println("6.Exit");
            System.out.println("Select a choice:");
            Scanner sc = new Scanner(System.in);
            choice = sc.nextInt();

            switch (choice) {

                case 0:
                    int chainSize = b.getChainSize();
                    int numberOfHashes = b.hashesPerSecond();
                    System.out.println("Current size of chain: "+chainSize);
                    System.out.println("Current hashes per second by this machine: "+numberOfHashes);
                    break;

                case 1:
                    blockCount = blockCount + 1;
                    System.out.println("Enter difficulty > 0");
                    difficulty = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter transaction:");
                    transaction = sc.nextLine();
                    Timestamp timestamp1 = b.getTime();
                    //the block to be added to the blockchain is initialized
                    Block block = new Block(blockCount, timestamp1, transaction, difficulty);
                    block.setPreviousHash(chainHash);
                    b.addBlock(block);
                    Timestamp timestamp2 = b.getTime();
                    long executionTime;
                    executionTime = timestamp2.getTime() - timestamp1.getTime();
                    System.out.println("Total execution time to add this block was " + executionTime + " milliseconds");
                    break;

                case 2:
                    boolean result;
                    Timestamp timestampverify1 = b.getTime();
                    //the function to verify the blockchain is called
                    result = b.isChainValid();
                    Timestamp timestampverify2 = b.getTime();
                    long executionTime1;
                    executionTime1 = timestampverify2.getTime() - timestampverify1.getTime();
                    System.out.println("Total execution time to verify the BlockChain was " + executionTime1 + " milliseconds");
                    break;

                case 3:
                    String string;
                    string = b.toString();
                    System.out.println("View the BlockChain");
                    System.out.println(string);
                    break;

                case 4:
                    System.out.println("Corrupt the Blockchain");
                    System.out.println("Enter block ID of block to corrupt");
                    int blockId = sc.nextInt();
                    System.out.println("Enter new data for block " + blockId);
                    sc.nextLine();
                    String newData = sc.nextLine();
                    Block b1 = Blocks.get(blockId);
                    b1.setData(newData);
                    System.out.println("The new data added at index" + blockId + "is:");
                    System.out.println(b1.getData());
                    break;

                case 5:

                    Timestamp timestamprepair1 = b.getTime();
                    System.out.println("Repairing the entire chain");
                    b.repairChain();
                    Timestamp timestamprepair2 = b.getTime();
                    long executionTime2;
                    executionTime2 = timestamprepair2.getTime() - timestamprepair1.getTime();
                    System.out.println("Total execution time to repair the BlockChain was " + executionTime2 + " milliseconds");
                    break;

                case 6:
                    break;

            }
        } while (choice != 6);

    }

    /**
     *
     * @return returns the size of the blockchain
     */
    public int getChainSize() {
        
        int chainSize=0;
        chainSize = Blocks.size();
        
        return chainSize;
    }

    /**
     *
     * @return returns the number of hashes that can be calculated in a second over the string "00000000"
     * @throws UnsupportedEncodingException
     * @throws NoSuchAlgorithmException
     */
    public int hashesPerSecond() throws UnsupportedEncodingException, NoSuchAlgorithmException {

        int numberOfHashes = 0; 
        String string ="00000000";
        long start = System.currentTimeMillis();
        while(System.currentTimeMillis() - start < 1000){
            //calculates the hash of the string using SHA-256
            MessageDigest digest = MessageDigest.getInstance("SHA-256"); 
            byte[] inputbytes = digest.digest(string.getBytes("UTF-8"));
            DatatypeConverter.printHexBinary(inputbytes);
            numberOfHashes = numberOfHashes+1;

        }
        
        return numberOfHashes;
    }

    /**
     *
     * @return returns the reference to the latest block
     */
    public Block getLatestBlock() {

        int size=Blocks.size();
        Block b = Blocks.get( size-1);
        return b;

    }

    /**
     *
     * @return returns the current system time
     */
    public Timestamp getTime() {

        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
        return currentTimestamp;

    }

    /**
     *
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     * This routine repairs the chain. It checks the hashes of each block and ensures that any illegal hashes are recomputed. 
     * After this routine is run, the chain will be valid. 
     * The routine does not modify any difficulty values. 
     * It computes new proof of work based on the difficulty specified in the Block.
     */
    public void repairChain() throws NoSuchAlgorithmException, UnsupportedEncodingException {

        int i = 0;
        chainHash = "";
        for (i = 0; i < getChainSize(); i++) {

            Block b = Blocks.get(i);
            b.nonce = new BigInteger("0");
            b.setPreviousHash(chainHash);
            String newHash = b.proofOfWork();
            chainHash = newHash;
        }

    }

    /**
     *
     * @param newBlock is added to the BlockChain as the most recent block
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     * A new Block is being added to the BlockChain. 
     * This new block's previous hash must hold the hash of the most recently added block. 
     */
    public void addBlock(Block newBlock) throws NoSuchAlgorithmException, UnsupportedEncodingException {

        Blocks.add(newBlock);
        String newHash = newBlock.proofOfWork();
        chainHash = newHash;

    }

    /**
     *
     * @return returns true if and only if the chain is valid
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     */
    public boolean isChainValid() throws NoSuchAlgorithmException, UnsupportedEncodingException {

        String nextHash = null;
        String newHash = null;
        int i = 0;
        System.out.println("Verifying the entire chain");
        if (getChainSize() == 0) {
            System.out.println("No blocks in the Blockchain");
            return true;

        } else if (getChainSize() == 1) {
            Block b = Blocks.get(i);
            String hash = b.proofOfWork();
            int j = 0;
            while (hash.charAt(j) == '0') {
                j = j + 1;
            }
            if (j == b.getDifficulty() && hash.equals(chainHash)) {
                System.out.println("Chain verification: true");
                return true;
            } else {
                System.out.println("Chain verification: false");
                int difficulty = b.getDifficulty();
                System.out.println("...Improper hash on node " + i + "Does not begin with " + difficulty + " zeroes");
                return false;
            }
        } else {
            do {
                Block b = Blocks.get(i);
                Block bnext = Blocks.get(i + 1);
                nextHash = bnext.getPreviousHash();
                newHash = b.proofOfWork();
                int j = 0;
                while (newHash.charAt(j) == '0') {
                    j = j + 1;
                }
                if (j != b.getDifficulty()) {
                    System.out.println("Chain verification: false");
                    int difficulty = b.getDifficulty();
                    System.out.println("...Improper hash on node " + i + "Does not begin with " + difficulty + " zeroes");
                    return false;
                }
                else if(!nextHash.equals(newHash)){
                System.out.println("Chain verification: false");
                System.out.println("...Improper hash on node " + (i-1));
                return false;
                }
                i = i + 1;

            } while (i != getChainSize() - 1);

            //if the block is the last block in the chain
            if (i == getChainSize() - 1) {
                Block b = Blocks.get(i);
                newHash = b.proofOfWork();
                if (chainHash.equals(newHash)) {
                    System.out.println("Chain verification: true");
                    return true;
                } else {
                    System.out.println("Chain verification: false");
                    System.out.println("...Improper hash on node " + (i));
                    return false;
                }
            } 
            
        }
        return false;

    }

    @Override
    public String toString() {

        String chain = "";
        int i = 0;
        for (i = 0; i < getChainSize(); i++) {

            Block b = Blocks.get(i);
            chain = chain + "{\"ds_chain\":[{\"index\":" + i + ",\"time stamp\": \""
                    + b.getTimestamp() + "\",\"Tx\": \"" + b.getData() + "\"," + "\n\"PrevHash\" : \"" + b.getPreviousHash()
                    + "\",\"nonce\":" + b.nonce + ",\"difficulty\":" + b.getDifficulty() + "}\n";
            if (i == Blocks.size() - 1) {

                chain = chain + "],\"chainHash\":\"" + chainHash + "\"}";
            }

        }
        return chain;
    }

}
