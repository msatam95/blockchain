/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mansi
 */
@WebServlet(urlPatterns = {"/BlockChainServer/*"})
public class BlockChainServer extends HttpServlet {
    

    BlockChain b;
    int blockCount = 0;
    int token =0;
    BigInteger e = new BigInteger("65537");
    BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    

    // GET returns a value given a key
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, UnsupportedEncodingException {

        System.out.println("Console: doGET visited");
        if(token==0){
            try {
                b = new BlockChain();
                token = token +1;
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(BlockChainServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        boolean result;
        String chain = null;
        // The name is on the path /name so skip over the '/'
        String name = (request.getPathInfo()).substring(1);
        String getResult ="";
        // return 401 if name not provided
        if (name.equals("2")) {
            
            response.setStatus(200);
            try {
                result = validateChain();
                
                if(result){
                    
                    getResult ="true";
                }
                else{
                    getResult ="false";
                }
                
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(BlockChainServer.class.getName()).log(Level.SEVERE, null, ex);
            }
           
            PrintWriter out = response.getWriter();
            out.println(getResult);
           
        }
        
        if (name.equals("3")) {
            
            
            try {
              chain = display();
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(BlockChainServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            PrintWriter out = response.getWriter();
            out.println(chain);
           
        }
        
        
    }
    
    
    public boolean validateChain() throws NoSuchAlgorithmException, UnsupportedEncodingException {
        
        boolean result;
        result = b.isChainValid();  
        return result;
    }

    
    public String display() throws NoSuchAlgorithmException, UnsupportedEncodingException {
        
        String string;
        string = b.toString(); 
        return string;
    }

    

    // POST is used to create a new variable
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, UnsupportedEncodingException {
        
        if(token==0){
            try {
                b = new BlockChain();
                token = token +1;
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(BlockChainServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        boolean val;
        System.out.println("Console: doPost visited");

        // To look at what the client accepts examine request.getHeader("Accept")
        // We are not using the accept header here.
        // Read what the client has placed in the POST data area
        BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
        String data = br.readLine();
        
        String[] split = data.split("@");
        
        String difficult = split[0];
        
        String signed = split[1];
        int difficulty = Integer.parseInt(difficult);
        
        try {
            
            val = addTransaction(difficulty,signed);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(BlockChainServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(val = true){
            response.setStatus(200);
        }
        else{
            
            response.setStatus(401);
        }
        
    }
    
    public boolean addTransaction( int difficulty, String transaction) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        
        
        boolean value=false;
        int sizeBefore = b.getChainSize();
        String[] strarray = transaction.split("#");
        // Take the encrypted string and make it a big integer
        BigInteger encryptedHash = new BigInteger(strarray[1]);
        // Decrypt it
        BigInteger decryptedHash = encryptedHash.modPow(e, n);
        
        // Get the bytes from messageToCheck
        byte[] bytesOfMessageToCheck = strarray[0].getBytes("UTF-8");
       
        // compute the digest of the message with SHA-256
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] messageToCheckDigest = md.digest(bytesOfMessageToCheck);
        int length = messageToCheckDigest.length;
        byte[] extrabyte = new byte[length+1];
        int i;
        extrabyte[0]=0; 
        for(i=1;i<length;i++){
                        
           extrabyte[i] = messageToCheckDigest[i];
                        
        }
        BigInteger bigIntegerToCheck = new BigInteger(extrabyte);
        Timestamp timestamp1 = b.getTime();
        // inform the client on how the two compare
        if(bigIntegerToCheck.compareTo(decryptedHash) == 0) {
         
        Block block = new Block(blockCount, timestamp1, transaction, difficulty);
        block.setPreviousHash(b.chainHash);
        b.addBlock(block);
        int sizeAfter = b.getChainSize();
        
            if(sizeBefore > sizeAfter){
            
            value = true;
        } else{
            value = false;
        }
        
        blockCount=blockCount+1;
          
        }
          
        return value;
        
    }   

}
