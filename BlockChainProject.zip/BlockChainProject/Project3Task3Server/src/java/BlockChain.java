/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;


/**
 *
 * @author mansi
 */
public class BlockChain {
    
    /**
     * @param args the command line arguments
     */
    static ArrayList<Block> Blocks = null;
    //initializing the Arraylist of blocks 
    static String chainHash = null;
    //initializing the chainhash variable to store the latest hash value

    BlockChain() throws NoSuchAlgorithmException, UnsupportedEncodingException {

        Blocks = new ArrayList<>();
        chainHash = "";
        Block block0 = new Block(0, this.getTime(), "Genesis", 2);
        block0.setPreviousHash(chainHash);
        //add the genesisz block to the chain
        this.addBlock(block0);

    }

    /**
     *
     * @return returns the size of the blockchain
     */
    public int getChainSize() {
        
        int chainSize;
        chainSize = Blocks.size();
        
        return chainSize;
    }

    /**
     *
     * @return returns the reference to the latest block
     */
    public Block getLatestBlock() {

        int size=Blocks.size();
        Block b = Blocks.get(size-1);
        return b;

    }

    /**
     *
     * @return returns the current system time
     */
    public Timestamp getTime() {

        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
        return currentTimestamp;

    }
    
    /**
     *
     * @param newBlock to be added to the BlockChain as the most recent block
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     * 
     * A new Block is being added to the BlockChain. 
     * This new block's previous hash must hold the hash of the most recently added block. 
     */
    public void addBlock(Block newBlock) throws NoSuchAlgorithmException, UnsupportedEncodingException {

        Blocks.add(newBlock);
        String newHash = newBlock.proofOfWork();
        chainHash = newHash;

    }

    /**
     *
     * @return returns true if and only if the chain is valid
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     */
    public boolean isChainValid() throws NoSuchAlgorithmException, UnsupportedEncodingException {

        String nextHash = null;
        String newHash = null;
        int i = 0;
        
        if (getChainSize() == 0) {

            System.out.println("No blocks in the Blockchain");
            return true;

        } else if (getChainSize() == 1) {

            Block b = Blocks.get(i);
            String hash = b.proofOfWork();
            int j = 0;
            while (hash.charAt(j) == '0') {

                j = j + 1;
            }
            if (j == b.getDifficulty() && hash.equals(chainHash)) {

                //System.out.println("Chain verification: true");
                return true;

            } else {

                System.out.println("Chain verification: false");
                int difficulty = b.getDifficulty();
                System.out.println("...Improper hash on node " + i + "Does not begin with " + difficulty + " zeroes");
                return false;

            }

        } else {
            do {
                Block b = Blocks.get(i);
                Block bnext = Blocks.get(i + 1);
                nextHash = bnext.getPreviousHash();
                newHash = b.proofOfWork();
                int j = 0;
                while (newHash.charAt(j) == '0') {

                    j = j + 1;
                }
                if (j != b.getDifficulty()) {

                    System.out.println("Chain verification: false");
                    int difficulty = b.getDifficulty();
                    System.out.println("...Improper hash on node " + i + "Does not begin with " + difficulty + " zeroes");
                    return false;
                }
                else if(!nextHash.equals(newHash)){
                    
                System.out.println("Chain verification: false");
                System.out.println("...Improper hash on node " + (i-1));
                return false;
                }
                i = i + 1;

            } while (i != getChainSize() - 1);

            //if the block is the last block in the chain
            if (i == getChainSize() - 1) {

                Block b = Blocks.get(i);
                newHash = b.proofOfWork();
                if (chainHash.equals(newHash)) {

                    System.out.println("Chain verification: true");
                    return true;
                } else {
                    System.out.println("Chain verification: false");
                    System.out.println("...Improper hash on node " + (i));
                    return false;
                }

            } 
            
        }
        return false;

    }

    @Override
    public String toString() {

        String chain = "";
        int i = 0;
        for (i = 0; i < getChainSize(); i++) {

            Block b = Blocks.get(i);
            chain = chain + "{\"ds_chain\":[{\"index\":" + i + ",\"time stamp\": \""
                    + b.getTimestamp() + "\",\n\"Tx\": \"" + b.getData() + "\"," + "\n\"PrevHash\" : \"" + b.getPreviousHash()
                    + "\",\"nonce\":" + b.nonce + ",\"difficulty\":" + b.getDifficulty() + "}\n";
            if (i == Blocks.size() - 1) {

                chain = chain + "],\"chainHash\":\"" + chainHash + "\"}";
            }

        }
        return chain;
    }


    
}
