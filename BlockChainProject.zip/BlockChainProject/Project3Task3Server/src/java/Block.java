/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author mansi
 */
public class Block {

    private int index;
    private Timestamp timestamp;
    private String data;
    private int difficulty;
    private String perviousHash;
    BigInteger nonce;

    //constructor for a block
    public Block(int index, Timestamp timestamp, String data, int difficulty) {
     
        this.index = index;
        this.timestamp = timestamp;
        this.data = data;
        this.difficulty = difficulty;
        this.nonce = new BigInteger("0");

    }

    /**
     *
     * @return returns the data stored in the current block.
     */
    public String getData() {

        return this.data;

    }

    /**
     *
     * @param data is the transaction to be set to the data field of the current block
     */
    public void setData(String data) {

        this.data = data;

    }

    /**
     *
     * @return returns the difficulty of the current block
     */
    public int getDifficulty() {

        return this.difficulty;
    }

    /**
     *
     * @param difficulty is the difficulty to be set to the current block
     */
    public void setDifficulty(int difficulty) {

        this.difficulty = difficulty;
    }

    /**
     *
     * @return returns the index of the current block
     */
    public int getIndex() {

        return this.index;
    }

    /**
     *
     * @return returns the hash of the block previous to the current block
     */
    public String getPreviousHash() {

        return this.perviousHash;
    }

    /**
     *
     * @param previousHash sets the hash of the block previous to the current block
     */
    public void setPreviousHash(String previousHash) {

        this.perviousHash = previousHash;
    }

    /**
     *
     * @param index is the index variable of the current block to be set
     */
    public void setIndex(int index) {

        this.index = index;
    }

    /**
     *
     * @param timestamp is the timestamp value when the current block was created
     */
    public void setTimestamp(Timestamp timestamp) {

        this.timestamp = timestamp;

    }

    /**
     *
     * @return returns the timestamp value when the current block was created
     */
    public Timestamp getTimestamp() {

        return this.timestamp;
    }

    /**
     *
     * @returns the hash calculated
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     * The proof of work methods finds a good hash. 
     * It increments the nonce until it produces a good hash.
     * This method calls calculateHash() to compute a hash of the concatenation 
     * of the index, timestamp, data, previousHash, nonce, and difficulty. 
     */
    public String proofOfWork() throws NoSuchAlgorithmException, UnsupportedEncodingException {

        int i = 0;
        String hash = null;
        if(nonce.compareTo(new BigInteger("0"))==0){
         while (i != this.difficulty){
             i=0;
             hash = calculateHash();
             while (hash.charAt(i) == '0') {

                i=i+1;
            }
            nonce=nonce.add(new BigInteger("1"));
             
         }
         nonce=nonce.subtract(new BigInteger("1"));
        
        return hash;
        
        }
            
        else{
            
            hash = calculateHash();
            return hash;       
        }
     
    }

    @Override
    public String toString() {

        return null;

    }

    /**
     *
     * @return returns the calculated hash 
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     * This method computes a hash of the concatenation of the index, timestamp, data, previousHash, nonce, and difficulty
     */
    public String calculateHash() throws NoSuchAlgorithmException, UnsupportedEncodingException {

        String concat ="";

        concat = Integer.toString(this.index) + this.timestamp.toString() + this.data + this.perviousHash + this.nonce.toString() + Integer.toString(this.difficulty);
        MessageDigest digest = MessageDigest.getInstance("SHA-256"); 
        byte[] inputbytes = digest.digest(concat.getBytes("UTF-8"));
        String hash = DatatypeConverter.printHexBinary(inputbytes);
        return hash;
    }

}
