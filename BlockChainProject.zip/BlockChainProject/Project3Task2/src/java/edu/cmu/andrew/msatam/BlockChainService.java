/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cmu.andrew.msatam;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author mansi
 */
@WebService(serviceName = "BlockChainService")
public class BlockChainService {

    /**
     * This is a sample web service operation
     */
    BlockChain b;
    int token =0;
    int blockCount = 0;
    BigInteger e = new BigInteger("65537");
    BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");

    /**
     * Web service operation
     *
     * @param xml
     * @return
     */
    @WebMethod(operationName = "xmlParse")
    public String xmlParse(@WebParam(name = "xml") String xml) throws SAXException, IOException, ParserConfigurationException, NoSuchAlgorithmException {
        //TODO write your implementation code here:
        String result = null;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        InputStream inputStream = new ByteArrayInputStream(xml.getBytes());
        builder = factory.newDocumentBuilder();

        Document blockChainMessage = builder.parse(inputStream);
        blockChainMessage.getDocumentElement().normalize();

        Element root = blockChainMessage.getDocumentElement();

        NodeList child = root.getChildNodes();
        String[] values = new String[child.getLength()];

        for (int i = 0; i < child.getLength(); i++) {

            values[i] = child.item(i).getTextContent();
            System.out.println(values[i]);

        }
      

        //adding the genesis block
        if(token==0){
            
        b = new BlockChain();
        blockCount = blockCount + 1;
        token = token+1;
        }
        if ("1".equals(values[0])) {

            Timestamp timestamp1 = b.getTime();
            String[] strarray = values[2].split("#");
            // Take the encrypted string and make it a big integer
            BigInteger encryptedHash = new BigInteger(strarray[1]);
            // Decrypt it
            BigInteger decryptedHash = encryptedHash.modPow(e, n);

            // Get the bytes from messageToCheck
            byte[] bytesOfMessageToCheck = strarray[0].getBytes("UTF-8");

            // compute the digest of the message with SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] messageToCheckDigest = md.digest(bytesOfMessageToCheck);
            int length = messageToCheckDigest.length;
            byte[] extrabyte = new byte[length + 1];
            int i;
            extrabyte[0] = 0;
            for (i = 1; i < length; i++) {

                extrabyte[i] = messageToCheckDigest[i];

            }
            BigInteger bigIntegerToCheck = new BigInteger(extrabyte);
            // inform the client on how the two compare
            if (bigIntegerToCheck.compareTo(decryptedHash) == 0) {

                //check the value of the transaction to be passed to the chain
                Block block = new Block(blockCount, timestamp1, values[2], Integer.parseInt(values[1]));
                block.setPreviousHash(b.chainHash);
                b.addBlock(block);
                Timestamp timestamp2 = b.getTime();
                long executionTime;
                executionTime = timestamp2.getTime() - timestamp1.getTime();
                blockCount = blockCount + 1;
                result = Long.toString(executionTime);

            }

        }
        if ("2".equals(values[0])) {

            boolean returnVal;
            System.out.println("Reached the call of isChainValid");
            returnVal = b.isChainValid();
            if (returnVal) {
                result = "true";
            } else {
                result = "false";
            }

        }
        if ("3".equals(values[0])) {

            result = b.toString();

        }
        return result;

    }

}
