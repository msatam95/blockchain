/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blockchainclient;



import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

/**
 *
 * @author mansi
 */
public class BlockChainClient {

    /**
     * @param args the command line arguments
     * @throws java.io.UnsupportedEncodingException
     * @throws java.security.NoSuchAlgorithmException
     */
    public static void main(String[] args) throws NoSuchAlgorithmException, UnsupportedEncodingException, UnsupportedEncodingException, NoSuchAlgorithmException {

        int choice;
        int difficulty;
        String transaction;
        BigInteger e = new BigInteger("65537");
        BigInteger d = new BigInteger("339177647280468990599683753475404338964037287357290649639740920420195763493261892674937712727426153831055473238029100340967145378283022484846784794546119352371446685199413453480215164979267671668216248690393620864946715883011485526549108913");
        BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
        init();

        do {
            System.out.println("Block Chain Menu");
            System.out.println("1.Add a transaction to the blockchain");
            System.out.println("2.Verify the blockchain");
            System.out.println("3.View the blockchain");
            System.out.println("4.Exit");
            System.out.println("Select a choice:");
            Scanner sc = new Scanner(System.in);
            choice = sc.nextInt();

            switch (choice) {

                case 1:

                    System.out.println("Enter difficulty > 0");
                    difficulty = sc.nextInt();
                    System.out.println("Enter transaction:");
                    transaction = sc.next();
                    //encode the transaction here
                    // compute the digest with SHA-256
                    byte[] bytesOfMessage = transaction.getBytes("UTF-8");
                    MessageDigest md = MessageDigest.getInstance("SHA-256");
                    byte[] bigDigest = md.digest(bytesOfMessage);
                    int length = bigDigest.length;
                    byte[] messageDigest = new byte[length+1];
                    int i;
                    messageDigest[0]=0; 
                    for(i=1;i<length;i++){
                        
                        messageDigest[i] = bigDigest[i];
                        
                    }
                    // From the digest, create a BigInteger
                    BigInteger m = new BigInteger(messageDigest); 
                    // encrypt the digest with the private key
                    BigInteger c = m.modPow(d, n);  
                    transaction = transaction+"#"+c.toString();
                    long executionTime = addTransaction(difficulty,transaction);
                    System.out.println("Total execution time to add this block was " + executionTime + " milliseconds");
                    break;

                case 2:

                    System.out.println("Verifying the entire chain");
                    boolean result = validateChain();
                    if (result == true) {
                        System.out.println("Chain verification: true");
                    } else {

                        System.out.println("Chain verification: false");

                    }
                    break;

                case 3:

                    System.out.println("View the BlockChain");
                    String chain = display();
                    System.out.println(chain);
                    break;

                case 4:

                    break;

            }
        } while (choice != 4);
    }

    private static long addTransaction(int difficulty, java.lang.String transaction) throws edu.cmu.andrew.msatam.UnsupportedEncodingException_Exception, edu.cmu.andrew.msatam.NoSuchAlgorithmException_Exception {
        edu.cmu.andrew.msatam.BlockChainWebService_Service service = new edu.cmu.andrew.msatam.BlockChainWebService_Service();
        edu.cmu.andrew.msatam.BlockChainWebService port = service.getBlockChainWebServicePort();
        return port.addTransaction(difficulty, transaction);
    }

    private static String display() throws edu.cmu.andrew.msatam.NoSuchAlgorithmException_Exception, edu.cmu.andrew.msatam.UnsupportedEncodingException_Exception {
        edu.cmu.andrew.msatam.BlockChainWebService_Service service = new edu.cmu.andrew.msatam.BlockChainWebService_Service();
        edu.cmu.andrew.msatam.BlockChainWebService port = service.getBlockChainWebServicePort();
        return port.display();
    }

    private static void init() throws UnsupportedEncodingException_Exception, NoSuchAlgorithmException_Exception {
        edu.cmu.andrew.msatam.BlockChainWebService_Service service = new edu.cmu.andrew.msatam.BlockChainWebService_Service();
        edu.cmu.andrew.msatam.BlockChainWebService port = service.getBlockChainWebServicePort();
        port.init();
    }

    private static boolean validateChain() throws NoSuchAlgorithmException_Exception, UnsupportedEncodingException_Exception {
        edu.cmu.andrew.msatam.BlockChainWebService_Service service = new edu.cmu.andrew.msatam.BlockChainWebService_Service();
        edu.cmu.andrew.msatam.BlockChainWebService port = service.getBlockChainWebServicePort();
        return port.validateChain();
    }

    

    

}
