/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3task2client;

import edu.cmu.andrew.msatam.IOException_Exception;
import edu.cmu.andrew.msatam.ParserConfigurationException_Exception;
import edu.cmu.andrew.msatam.SAXException_Exception;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;


/**
 *
 * @author mansi
 */
public class Project3Task2Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, NoSuchAlgorithmException, IOException_Exception, ParserConfigurationException_Exception, SAXException_Exception {

        int choice;
        int difficulty;
        String transaction;
        String xml="";
        String result = null;
        BigInteger e = new BigInteger("65537");
        BigInteger d = new BigInteger("339177647280468990599683753475404338964037287357290649639740920420195763493261892674937712727426153831055473238029100340967145378283022484846784794546119352371446685199413453480215164979267671668216248690393620864946715883011485526549108913");
        BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");

        do {
            System.out.println("Block Chain Menu");
            System.out.println("1.Add a transaction to the blockchain");
            System.out.println("2.Verify the blockchain");
            System.out.println("3.View the blockchain");
            System.out.println("4.Exit");
            System.out.println("Select a choice:");
            Scanner sc = new Scanner(System.in);
            choice = sc.nextInt();

            switch (choice) {

                case 1:

                    xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?><Menu>";
                    System.out.println("Enter difficulty > 0");
                    difficulty = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter transaction:");
                    transaction = sc.nextLine();
                    //encode the transaction here
                    // compute the digest with SHA-256
                    byte[] bytesOfMessage = transaction.getBytes("UTF-8");
                    MessageDigest md = MessageDigest.getInstance("SHA-256");
                    byte[] bigDigest = md.digest(bytesOfMessage);
                    int length = bigDigest.length;
                    byte[] messageDigest = new byte[length + 1];
                    int i;
                    messageDigest[0] = 0;
                    for (i = 1; i < length; i++) {

                        messageDigest[i] = bigDigest[i];

                    }
                    // From the digest, create a BigInteger
                    BigInteger m = new BigInteger(messageDigest);
                    // encrypt the digest with the private key
                    BigInteger c = m.modPow(d, n);
                    transaction = transaction + "#" + c.toString();
                    
                    xml=xml+"<choice>1</choice><difficulty>"+difficulty+"</difficulty><transaction>"+transaction+"</transaction></Menu>";
                    result = xmlParse(xml);
                    long executionTime = Long.parseLong(result);
                    System.out.println("Total execution time to add this block was " + executionTime + " milliseconds");
                    
                    break;

                case 2:

                    System.out.println("Verifying the entire chain");
                    xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?><Menu>";
                    xml=xml+"<choice>2</choice><difficulty></difficulty><transaction></transaction></Menu>";
                    result = xmlParse(xml);
                    
                    if (result.equals("true")) {
                        System.out.println("Chain verification: true");
                    } else {

                        System.out.println("Chain verification: false");

                    }
                    break;

                case 3:

                    System.out.println("View the BlockChain");
                    xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?><Menu>";
                    xml=xml+"<choice>3</choice><difficulty></difficulty><transaction></transaction></Menu>";
                    result = xmlParse(xml);
                    System.out.println(result);
                    break;

                case 4:

                    break;

            }
        } while (choice != 4);
        
    }

  //parses the xml file 
private static String xmlParse(java.lang.String xml) throws IOException_Exception, ParserConfigurationException_Exception, SAXException_Exception{
        edu.cmu.andrew.msatam.BlockChainService_Service service = new edu.cmu.andrew.msatam.BlockChainService_Service();
        edu.cmu.andrew.msatam.BlockChainService port = service.getBlockChainServicePort();
        return port.xmlParse(xml);
    }
      
    

}
